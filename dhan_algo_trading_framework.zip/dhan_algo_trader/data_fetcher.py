def fetch_ltp(symbol):
    # Placeholder for LTP fetching logic
    return {"ltp": 2500.0}
