DHAN_API_KEY = "your_api_key"
DHAN_ACCESS_TOKEN = "your_access_token"
TELEGRAM_BOT_TOKEN = "your_telegram_token"
TELEGRAM_CHAT_ID = "your_chat_id"
