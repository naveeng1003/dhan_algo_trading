def start_websocket():
    print("WebSocket started... [placeholder]")
