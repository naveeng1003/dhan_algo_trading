import requests
from dhan_algo_trader.config import DHAN_API_KEY, DHAN_ACCESS_TOKEN

def place_bracket_order(order):
    print(f"Placing order: {order}")
    # Implement your SL/TP logic here
