def check_trade_signal(data):
    # Example: moving average crossover logic placeholder
    return {
        "action": "BUY",
        "symbol": "RELIANCE",
        "quantity": 1,
        "price": data["ltp"]
    }
